# YouTuber Badge Mod

A simple mod that gives YouTubers / Popular figures a badge in Geometry Dash to help identify their profiles!