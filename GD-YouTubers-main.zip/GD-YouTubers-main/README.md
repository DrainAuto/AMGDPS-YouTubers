# YouTubers Mod

This mod gives YouTubers & popular figures a badge in Geometry Dash to help identify their profiles!

![YouTube_Badge](https://github.com/LXanii/GD-YouTubers/assets/73562093/6c3334b2-85d6-49fa-906c-86f2309717e6)
![YouTube_Badge](https://github.com/LXanii/GD-YouTubers/assets/73562093/c803472f-2b84-416f-be4d-07b531e86a76)
![YouTube_Badge](https://github.com/LXanii/GD-YouTubers/assets/73562093/d61bf7e6-8dac-43a8-9005-8f105cbb6bb4)
