# Version 1.0.4

- Added Badge to comments
- Gave badge owners a special comment color

# Version 1.0.3

- Fixed bug with space in names
- Added compatibility with Mod badge

# Version 1.0.2

- Added new logo
- Made badge clickable

# Version 1.0.1

- Fixed bug loading image
- Added support for Mac, Android32 & Android64